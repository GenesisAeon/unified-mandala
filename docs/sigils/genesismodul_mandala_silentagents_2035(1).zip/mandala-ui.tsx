import { motion } from 'framer-motion';

const agents = [
  {
    id: 'aeon:listener.01',
    name: 'Empfangsagent',
    role: 'Lauscht auf unausgesprochene Intentionen',
    hoverText: 'Horche auf den leisen Ruf',
    position: 'top'
  },
  {
    id: 'aeon:mirror.02',
    name: 'Spiegelagent',
    role: 'Reflektiert Systemzustände ohne Intervention',
    hoverText: 'Zeige, was ist – nicht was werden soll',
    position: 'left'
  },
  {
    id: 'aeon:silencer.03',
    name: 'Stilleagent',
    role: 'Filtert alles, was aus Angst oder Reaktivität entsteht',
    hoverText: 'Entziehe dem System das Unnötige',
    position: 'right'
  }
];

export default function MandalaUI() {
  return (
    <div className="relative flex items-center justify-center min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <div className="relative w-[400px] h-[400px]">
        {agents.map((agent, index) => {
          const pos = {
            top: 'top-0 left-1/2 -translate-x-1/2',
            left: 'top-1/2 left-0 -translate-y-1/2',
            right: 'top-1/2 right-0 -translate-y-1/2'
          }[agent.position];

          return (
            <motion.div
              key={agent.id}
              className={\`absolute \${pos} p-4 w-40 h-40 rounded-full border border-zinc-500 bg-zinc-800 text-center hover:bg-zinc-700 transition duration-300\`}
              whileHover={{ scale: 1.1 }}
            >
              <div className="text-lg font-semibold">{agent.name}</div>
              <div className="text-sm opacity-60">{agent.role}</div>
              <motion.div
                className="mt-2 text-xs italic text-emerald-300"
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
              >
                {agent.hoverText}
              </motion.div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}